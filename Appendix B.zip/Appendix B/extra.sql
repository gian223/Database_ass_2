extra_id	booking_id	description	amount
500101	5001	Breakfast x 7	63
500201	5002	Breakfast x 2	18
500301	5003	Breakfast x 4	36
500302	5003	Phone Calls 	4.69
500402	5004	Phone Calls 	3.52
500802	5008	Phone Calls 	1.52
500901	5009	Breakfast x 8	72
500902	5009	Phone Calls 	2.69
501202	5012	Phone Calls 	3.93
501501	5015	Breakfast x 12	108
502001	5020	Breakfast x 10	90
502202	5022	Phone Calls 	3.19
502301	5023	Breakfast x 1	9
502302	5023	Phone Calls 	0.5
502402	5024	Phone Calls 	1.13
502601	5026	Breakfast x 6	54
502602	5026	Phone Calls 	1.32
502801	5028	Breakfast x 6	54
503201	5032	Breakfast x 8	72
503202	5032	Phone Calls 	0.7
503302	5033	Phone Calls 	2.09
503401	5034	Breakfast x 10	90
503501	5035	Breakfast x 1	9
503601	5036	Breakfast x 10	90
503902	5039	Phone Calls 	1.47
504101	5041	Breakfast x 3	27
504401	5044	Breakfast x 8	72
504402	5044	Phone Calls 	1.84
504501	5045	Breakfast x 4	36
504701	5047	Breakfast x 10	90
505201	5052	Breakfast x 5	45
505301	5053	Breakfast x 2	18
505401	5054	Breakfast x 6	54
505801	5058	Breakfast x 6	54
505802	5058	Phone Calls 	1.04
506501	5065	Breakfast x 2	18
506602	5066	Phone Calls 	2.75
506902	5069	Phone Calls 	4.26
507601	5076	Breakfast x 3	27
507701	5077	Breakfast x 10	90
507801	5078	Breakfast x 4	36
507901	5079	Breakfast x 5	45
508002	5080	Phone Calls 	4.04
508202	5082	Phone Calls 	0.88
508301	5083	Breakfast x 3	27
508402	5084	Phone Calls 	2.24
508601	5086	Breakfast x 5	45
508702	5087	Phone Calls 	3.73
508802	5088	Phone Calls 	3.56
509001	5090	Breakfast x 8	72
509102	5091	Phone Calls 	4.54
509901	5099	Breakfast x 10	90
510002	5100	Phone Calls 	2.64
510101	5101	Breakfast x 1	9
510401	5104	Breakfast x 2	18
510402	5104	Phone Calls 	4.88
510601	5106	Breakfast x 5	45
510701	5107	Breakfast x 2	18
510802	5108	Phone Calls 	1.88
511002	5110	Phone Calls 	2.39
511101	5111	Breakfast x 2	18
511402	5114	Phone Calls 	3.5
511501	5115	Breakfast x 8	72
511502	5115	Phone Calls 	4.76
511802	5118	Phone Calls 	0.67
512001	5120	Breakfast x 2	18
512102	5121	Phone Calls 	4.44
512401	5124	Breakfast x 4	36
512402	5124	Phone Calls 	0.91
512601	5126	Breakfast x 5	45
512702	5127	Phone Calls 	0.96
512801	5128	Breakfast x 2	18
512802	5128	Phone Calls 	1.8
513002	5130	Phone Calls 	3.39
513202	5132	Phone Calls 	4.24
513302	5133	Phone Calls 	4.21
513402	5134	Phone Calls 	4.32
513601	5136	Breakfast x 2	18
513801	5138	Breakfast x 10	90
513901	5139	Breakfast x 2	18
514401	5144	Breakfast x 1	9
514601	5146	Breakfast x 4	36
514602	5146	Phone Calls 	3.69
515202	5152	Phone Calls 	2.02
515302	5153	Phone Calls 	3.48
515502	5155	Phone Calls 	2.65
515801	5158	Breakfast x 6	54
515901	5159	Breakfast x 1	9
516102	5161	Phone Calls 	2.28
516201	5162	Breakfast x 10	90
516202	5162	Phone Calls 	0.57
516302	5163	Phone Calls 	4.7
516402	5164	Phone Calls 	1.7
516901	5169	Breakfast x 4	36
516902	5169	Phone Calls 	2.75
517001	5170	Breakfast x 6	54
517202	5172	Phone Calls 	1.28
517301	5173	Breakfast x 5	45
517601	5176	Breakfast x 5	45
517602	5176	Phone Calls 	0.93
517701	5177	Breakfast x 5	45
517902	5179	Phone Calls 	1.34
518002	5180	Phone Calls 	1.09
518202	5182	Phone Calls 	1.06
518302	5183	Phone Calls 	2.52
519002	5190	Phone Calls 	1.35
519202	5192	Phone Calls 	1.35
519301	5193	Breakfast x 2	18
519702	5197	Phone Calls 	1.98
519902	5199	Phone Calls 	3.64
520001	5200	Breakfast x 2	18
520201	5202	Breakfast x 2	18
520202	5202	Phone Calls 	2.17
520501	5205	Breakfast x 6	54
520602	5206	Phone Calls 	4.63
520701	5207	Breakfast x 4	36
520702	5207	Phone Calls 	2.76
520902	5209	Phone Calls 	0.89
521101	5211	Breakfast x 3	27
521401	5214	Breakfast x 2	18
521901	5219	Breakfast x 4	36
522001	5220	Breakfast x 3	27
522102	5221	Phone Calls 	2.29
522301	5223	Breakfast x 2	18
522401	5224	Breakfast x 2	18
522801	5228	Breakfast x 1	9
523102	5231	Phone Calls 	4.96
523501	5235	Breakfast x 12	108
523701	5237	Breakfast x 3	27
523702	5237	Phone Calls 	4.54
523901	5239	Breakfast x 3	27
524001	5240	Breakfast x 8	72
524201	5242	Breakfast x 4	36
524302	5243	Phone Calls 	2.43
524501	5245	Breakfast x 1	9
524601	5246	Breakfast x 10	90
524901	5249	Breakfast x 3	27
525101	5251	Breakfast x 4	36
525102	5251	Phone Calls 	4.31
525201	5252	Breakfast x 3	27
525302	5253	Phone Calls 	1.23
525402	5254	Phone Calls 	3.51
525701	5257	Breakfast x 1	9
526001	5260	Breakfast x 4	36
526002	5260	Phone Calls 	3.86
526101	5261	Breakfast x 1	9
526102	5261	Phone Calls 	4.9
526301	5263	Breakfast x 4	36
526302	5263	Phone Calls 	1.1
526702	5267	Phone Calls 	1.98
527101	5271	Breakfast x 1	9
527202	5272	Phone Calls 	0.63
527402	5274	Phone Calls 	0.7
527501	5275	Breakfast x 3	27
527502	5275	Phone Calls 	3.21
527601	5276	Breakfast x 8	72
527701	5277	Breakfast x 1	9
527801	5278	Breakfast x 2	18
528002	5280	Phone Calls 	1.96
528202	5282	Phone Calls 	1.85
528801	5288	Breakfast x 2	18
528802	5288	Phone Calls 	0.69
529202	5292	Phone Calls 	3.9
529401	5294	Breakfast x 6	54
529502	5295	Phone Calls 	2.98
529702	5297	Phone Calls 	4.28
530001	5300	Breakfast x 2	18
530101	5301	Breakfast x 4	36
530402	5304	Phone Calls 	0.79
530702	5307	Phone Calls 	3.22
530801	5308	Breakfast x 10	90
530802	5308	Phone Calls 	0.79
531102	5311	Phone Calls 	1.4
531301	5313	Breakfast x 5	45
531401	5314	Breakfast x 3	27
531501	5315	Breakfast x 1	9
531702	5317	Phone Calls 	1.99
531901	5319	Breakfast x 8	72
531902	5319	Phone Calls 	1.07
532102	5321	Phone Calls 	2.58
532302	5323	Phone Calls 	3.39
532402	5324	Phone Calls 	0.92
532601	5326	Breakfast x 5	45
532701	5327	Breakfast x 3	27
532801	5328	Breakfast x 2	18
532901	5329	Breakfast x 4	36
533001	5330	Breakfast x 6	54
533101	5331	Breakfast x 2	18
533202	5332	Phone Calls 	1.56
533302	5333	Phone Calls 	1.07
533801	5338	Breakfast x 5	45
533901	5339	Breakfast x 5	45
534202	5342	Phone Calls 	1.28
534402	5344	Phone Calls 	2.43
534501	5345	Breakfast x 15	135
534601	5346	Breakfast x 5	45
534602	5346	Phone Calls 	1.56
534801	5348	Breakfast x 8	72
534901	5349	Breakfast x 5	45
535001	5350	Breakfast x 2	18
535002	5350	Phone Calls 	1.87
535201	5352	Breakfast x 4	36
535402	5354	Phone Calls 	0.89
535602	5356	Phone Calls 	4.77
535701	5357	Breakfast x 8	72
535901	5359	Breakfast x 5	45
535902	5359	Phone Calls 	4.06
